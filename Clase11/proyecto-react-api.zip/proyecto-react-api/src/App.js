/*
Importaciones:
Importamos React, useState, useEffect y el archivo CSS personalizado.
useState nos permite manejar estados en nuestro componente.
useEffect es usado para efectos secundarios, aunque en este caso no lo usamos explícitamente.

Estado inicial:
const [users, setUsers] = useState([]);
Inicializamos un array vacío para almacenar los usuarios.
setUsers es una función que actualizará este estado.

Control de carga:
const [loading, setLoading] = useState(false);
Manejamos un estado booleano para indicar si estamos cargando.
setLoading actualiza este estado.

Manejo de errores:
const [error, setError] = useState(null);
Almacenamos cualquier error que pueda ocurrir durante la carga.
setError actualiza este estado.

Función fetchData:
Esta función asíncrona realiza la petición HTTP a la API.
Usa try/catch para manejar posibles errores.
Actualiza los estados de carga y error según sea necesario.

Renderización:
El botón llama a fetchData cuando se presiona.
Muestra un mensaje de error si hay uno.
La tabla muestra los datos cuando no estamos cargando ni hay un error.
*/
import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  // Estado inicial de los usuarios
  const [users, setUsers] = useState([]);
  
  // Estado para controlar si estamos cargando
  const [loading, setLoading] = useState(false);
  
  // Estado para almacenar cualquier error que pueda ocurrir
  const [error, setError] = useState(null);

  // Función asíncrona para obtener los datos de la API
  const fetchData = async () => {
    // Setear loading a true antes de iniciar la carga
    setLoading(true);
    
    // Limpiar cualquier error anterior
    setError(null);
    
    try {
      // Hacer la petición GET a la API
      const response = await fetch('https://jsonplaceholder.typicode.com/users');
      
      // Comprobar si la respuesta fue exitosa
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      // Parsear el JSON de la respuesta
      const data = await response.json();
      
      // Actualizar el estado con los datos obtenidos
      setUsers(data);
    } catch (err) {
      // Almacenar cualquier error que ocurra
      setError(err.message);
      console.error('Error fetching data:', err);
    } finally {
      // Setear loading a false después de que terminemos de cargar o si hubo un error
      setLoading(false);
    }
  };

  return (
    <div className="container my-5 text-center">
      {/* Botón para obtener los datos */}
      <button className="btn btn-danger w-40" onClick={fetchData} disabled={loading}>
        {loading ? 'Cargando...' : 'Obtener API Externa'}
      </button>

      {/* Mostrar mensaje de error si hay uno */}
      {error && <div className="mt-2 text-danger">{error}</div>}

      {/* Tabla con los datos */}
      <table className="table table-striped table-dark mt-4">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {!loading && !error && (
            <>
              {users.length > 0 ? (
                // Mapear cada usuario a una fila de la tabla
                users.map(user => (
                  <tr key={user.id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                  </tr>
                ))
              ) : (
                // Mostrar mensaje si no hay usuarios
                <tr>
                  <td colSpan="2">No hay datos disponibles</td>
                </tr>
              )}
            </>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default App;

